import React, { useEffect, useState } from 'react'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Button } from '@material-ui/core';

function RestaurentUpdate(props) {

    const [id, setId] = useState("")
    const [name, setName] = useState("")
    const [address, setAddress] = useState("")
    const [rating, setRating] = useState("")



    useEffect(() => {
        console.log(props.match.params.id)

        fetch("http://localhost:3000/restaurent/" + props.match.params.id).then((result) => {
            result.json().then((response) => {
                setName(response.name)
                setId(response.id)
                setAddress(response.address)
                setRating(response.rating)
            })
        })
    }, [])

const update = () =>{
    let data = {id,name,address,rating}
    fetch("http://localhost:3000/restaurent/"+id,{
        method:'PUT',
        headers:{
            'Content-type':'application/json'
        },
        body:JSON.stringify(data)
                 }).then((result)=>{
            result.json().then((responce)=>{
                alert(`Restaurent update  ${name} ${rating} ${address}`)
            })
        })
}

    return (
        <div>
            <h1>RestaurentUpdate</h1>
            <div>
                <form onSubmit={(p) => update(p)}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>Id</TableCell>
                                <TableCell>Name</TableCell>
                                <TableCell>Address</TableCell>
                                <TableCell>Rating Out of 5</TableCell>
                                <TableCell>---</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow>
                                <TableCell><input type="text" placeholder="ID" disabled value={id}
                                    onChange={(e) => { setId(e.target.value) }} /></TableCell>

                                <TableCell><input type="text" placeholder="Name" value={name}
                                    onChange={(e) => { setName(e.target.value) }} /></TableCell>

                                <TableCell><input type="text" placeholder="Address" value={address}
                                    onChange={(e) => { setAddress(e.target.value) }} /></TableCell>

                                <TableCell><input type="text" placeholder="Rating" value={rating}
                                    onChange={(e) => { setRating(e.target.value) }} /></TableCell>

                                <TableCell><Button type="submit">Update</Button></TableCell>

                            </TableRow>
                        </TableBody>
                    </Table>
                </form>
            </div>
        </div>
    )
}

export default RestaurentUpdate

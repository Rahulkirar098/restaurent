import React from 'react';
import { Link, Route, Switch } from 'react-router-dom'
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import RestaurentCreate from "./RestaurentCreate";
import RestaurentDetail from "./RestaurentDetail";
import RestaurentList from "./RestaurentList";
import RestaurentSearch from "./RestaurentSearch";
import RestaurentUpdate from "./RestaurentUpdate";
import Login from "./Login";
import Logout from "./Logout";


const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    menuButton: {
        marginRight: theme.spacing(2),
    },
    title: {
        flexGrow: 1,
    },
}));

const Color = {
    color:"Black",
    textDecoration:"none"
}

export default function ButtonAppBar() {
    const classes = useStyles();

    return (
        <div className={classes.root}>
            <AppBar position="static" style={{backgroundColor:"orange"}}>
                <Toolbar>                   
                        <Button ><Link to="/" style={Color}>Home</Link></Button>
                        <Button ><Link to="/list" style={Color}>list</Link></Button>
                        <Button ><Link to="/create" style={Color}>create</Link></Button>
                        <Button ><Link to="/detail" style={Color}>detail</Link></Button>
                        <Button ><Link to="/search" style={Color}>search</Link></Button>
                        {
                            localStorage.getItem('username')?
                            <Button ><Link to="/logout" style={Color}>Logout</Link></Button> 
                            :
                            <Button ><Link to="/login" style={Color}>Login</Link></Button> 
                        }
                        

                </Toolbar>
            </AppBar>
            <Switch>
                        <Route path="/logout" component={Logout} />
                        <Route path="/create" component={RestaurentCreate} />
                        <Route path="/detail" component={RestaurentDetail} />
                        <Route path="/list" component={RestaurentList} />
                        <Route path="/search" component={RestaurentSearch} />
                        <Route path="/update/:id" render={props=>(<RestaurentUpdate {...props}/>)}/>
                        <Route path="/login" component={Login} />
            </Switch>
        </div>
    );
}

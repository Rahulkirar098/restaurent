import React from 'react'

function RestaurentDetail() {
    return (
        <div>
            <h1>restaurent Details</h1>
        </div>
    )
}

export default RestaurentDetail

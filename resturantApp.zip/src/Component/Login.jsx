import React, { useState } from 'react'
import { useHistory } from 'react-router-dom'

function Login () {

    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")

    
    const history = useHistory()

    const login = () =>{

        
    fetch("http://localhost:3000/login?q="+password).then((data)=>{
        data.json().then((response)=>{
            console.log(response);
            if(response.length>0){
                localStorage.setItem("username",JSON.stringify(response ))
                    history.push("/list")
                    console.log(`login sucess hye ${username}`)
            }
            else{
                alert("Enter Username and Password Correct")
            }

        })
    })
    }

    return (
        <div>
            <h1>LogIn</h1>
            <from>
            <input placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)}/>
            <br/>
            <br/>
            <input placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)}/>
            <br/>
            <br/>
            <button onClick={login}>Login</button>
            </from>
         </div>
    )
}
export default Login;
import React, { useState } from 'react'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Button } from '@material-ui/core';

function RestaurentCreate() {

    const [id, setId] = useState("")
    const [name, setName] = useState("")
    const [address, setAddress] = useState("")
    const [rating, setRating] = useState("")

    const Create = (p) =>{
        // p.preventDefault();
        let data = {id,name,address,rating}
        fetch("http://localhost:3000/restaurent",{
            method:'POST',
            headers:{
                'Content-type':'application/json'
            },
            body:JSON.stringify(data)
                     }).then((result)=>{
                result.json().then((responce)=>{
                    alert("Restaurent Create")
                })
            })
    }

 

    return (
        <div>
             <h1>Restaurent List</h1>
            <form onSubmit={(p) => Create(p)}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>Id</TableCell>
                        <TableCell>Name</TableCell>
                        <TableCell>Address</TableCell>
                        <TableCell>Rating</TableCell>
                        <TableCell>---</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    <TableRow>
                        <TableCell><input type="text" placeholder="ID" disabled value={id}
                            onChange={(e) => { setId(e.target.value) }} /></TableCell>

                        <TableCell><input type="text" placeholder="Name" value={name}
                            onChange={(e) => { setName(e.target.value) }} /></TableCell>

                        <TableCell><input type="text" placeholder="Address" value={address}
                            onChange={(e) => { setAddress(e.target.value) }} /></TableCell>

                        <TableCell><input type="text" placeholder="Rating" value={rating}
                            onChange={(e) => { setRating(e.target.value) }} /></TableCell>

                        <TableCell><Button type="submit">Create</Button></TableCell>

                    </TableRow>
                </TableBody>
            </Table>
            </form>
        </div>
    )
}

export default RestaurentCreate

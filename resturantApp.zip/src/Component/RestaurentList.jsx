import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';



function RestaurentList() {

    const [listdata, setListdata] = useState([])

   

    const refresh = () => {
        fetch("http://localhost:3000/restaurent").then((result) => {
            result.json().then((response) => {
                setListdata(response)
            })
        })
    }
    useEffect(() => { refresh() }, [])
    
    const deleted = (id) => {
        // id.preventDefault();
        fetch("http://localhost:3000/restaurent/" + id, {
            method: 'DELETE'
            // headers:{
            //     'Content-type':'application/json'
            // }
        }).then((result) => {
            result.json().then((responce) => {
                alert("Restaurent deleted")
                refresh()
            })
        })
    }


    return (
        <div>
            <h1>Restaurent List</h1>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>Id</TableCell>
                        <TableCell>Name</TableCell>
                        <TableCell>Address</TableCell>
                        <TableCell>Rating</TableCell>
                        <TableCell>Update</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {
                        listdata.map((item, index) =>
                            <TableRow>
                                <TableCell>{index}</TableCell>
                                <TableCell>{item.name}</TableCell>
                                <TableCell>{item.address}</TableCell>
                                <TableCell>{item.rating}</TableCell>
                                <TableCell> 
                                    <Link to={"/update/" + item.id}><EditIcon /></Link> 
                                    <span onClick={() => deleted(item.id)}> <DeleteIcon /></span> </TableCell>
                            </TableRow>
                        )
                    }
                </TableBody>
            </Table>
        </div>
    )
}

export default RestaurentList
